const product = 'Socks'
